My cs50 final project is a web application for generating chess tournaments. The tournaments are four rounds long. Each matchup is created based on each player's performance in the tournament. In the end, a winner is declared.

As the leader of the chess team at my school, I made this program to help organize in school chess tournaments. It won't be long before I get it test it out with the team.